import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.ppopshistory'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "UCK09g6gYGMvU-0x1VCF1hgA"
YOUTUBE_CHANNEL_ID_2 = "UCLDfUKCEbH5FFflf-NRHmuA"
YOUTUBE_CHANNEL_ID_3 = "UCzIZ8HrzDgc-pNQDUG6avBA"
YOUTUBE_CHANNEL_ID_4 = "UClfEht64_NrzHf8Y0slKEjw"

# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="Military History",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://upload.wikimedia.org/wikipedia/en/d/d0/History_channel_military.png",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="History",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://s-media-cache-ak0.pinimg.com/originals/72/4c/40/724c40a0c7249e8c6924d5953a27d20e.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="It's History So They Say",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://s-media-cache-ak0.pinimg.com/236x/5a/61/2f/5a612f583352224f06407d4639c6b977.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Alternate Reality History",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="http://www.webserieschannel.com/wp-content/uploads/2011/12/the-alternate-reality-show-web-series-logo-298x223.jpg",
        folder=True )		
			
run() 